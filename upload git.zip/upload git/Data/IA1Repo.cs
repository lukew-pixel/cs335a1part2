﻿using A1.Models;
using A1.Dtos;
using System.Collections.Generic;

namespace A1.Data
{
    public interface IA1Repo
    {
        IEnumerable<Sign> GetAllSigns();
        IEnumerable<Sign> FindSigns(string searchTerm);
        string GetSignImagePath(string id);
        Comment GetCommentById(int id);
        Comment AddComment(CommentInput input);
        IEnumerable<Comment> GetLatestComments(int number);
    }
}
