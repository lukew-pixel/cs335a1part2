﻿namespace A1.Dtos
{
    public class CommentInput
    {
        public string? UserComment { get; set; }
        public string? Name { get; set; }
    }
}
